"""
Sales Prediction using Python
=============================
CodeAlpha Data Science Internship - Task 4

Goal: Predict product Sales based on advertising spend across TV, Radio,
and Newspaper channels using regression, and extract business insights
on how advertising impacts sales.

Author: Priya Kumari
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.linear_model import LinearRegression
from sklearn.ensemble import RandomForestRegressor
from sklearn.preprocessing import PolynomialFeatures, StandardScaler
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score

sns.set_style("whitegrid")
plt.rcParams["figure.figsize"] = (8, 5)

OUTPUT_DIR = "outputs"


# ---------------------------------------------------------------------------
# 1. LOAD & CLEAN DATA
# ---------------------------------------------------------------------------
def load_data(path="data/advertising.csv"):
    df = pd.read_csv(path)

    # Drop unnamed index column that comes from the original CSV export
    unnamed_cols = [c for c in df.columns if "Unnamed" in c or c == ""]
    df = df.drop(columns=unnamed_cols, errors="ignore")

    print("Shape:", df.shape)
    print("\nMissing values:\n", df.isnull().sum())
    print("\nDuplicate rows:", df.duplicated().sum())

    # Clean up: drop duplicates, drop rows with missing target
    df = df.drop_duplicates()
    df = df.dropna(subset=["Sales"])

    # Fill any remaining missing feature values with column median
    for col in ["TV", "Radio", "Newspaper"]:
        if df[col].isnull().sum() > 0:
            df[col] = df[col].fillna(df[col].median())

    return df


# ---------------------------------------------------------------------------
# 2. EXPLORATORY DATA ANALYSIS
# ---------------------------------------------------------------------------
def explore_data(df):
    print("\nDescriptive statistics:\n", df.describe())

    # Correlation heatmap
    plt.figure()
    corr = df.corr()
    sns.heatmap(corr, annot=True, cmap="coolwarm", fmt=".2f")
    plt.title("Correlation Between Advertising Spend and Sales")
    plt.tight_layout()
    plt.savefig(f"{OUTPUT_DIR}/correlation_heatmap.png", dpi=150)
    plt.close()

    # Scatter plots: spend vs sales for each channel
    fig, axes = plt.subplots(1, 3, figsize=(16, 5))
    for ax, col in zip(axes, ["TV", "Radio", "Newspaper"]):
        sns.regplot(x=col, y="Sales", data=df, ax=ax,
                    scatter_kws={"alpha": 0.5}, line_kws={"color": "red"})
        ax.set_title(f"{col} Spend vs Sales")
    plt.tight_layout()
    plt.savefig(f"{OUTPUT_DIR}/spend_vs_sales.png", dpi=150)
    plt.close()

    # Distribution of Sales
    plt.figure()
    sns.histplot(df["Sales"], kde=True, bins=20)
    plt.title("Distribution of Sales")
    plt.tight_layout()
    plt.savefig(f"{OUTPUT_DIR}/sales_distribution.png", dpi=150)
    plt.close()

    print(f"\nEDA plots saved to '{OUTPUT_DIR}/'")
    return corr


# ---------------------------------------------------------------------------
# 3. FEATURE ENGINEERING
# ---------------------------------------------------------------------------
def engineer_features(df):
    df = df.copy()
    # Total advertising budget
    df["Total_Spend"] = df["TV"] + df["Radio"] + df["Newspaper"]
    # Share of budget going to TV (historically the strongest driver)
    df["TV_Share"] = df["TV"] / df["Total_Spend"].replace(0, np.nan)
    df["TV_Share"] = df["TV_Share"].fillna(0)
    # Interaction term: TV and Radio often have a synergistic effect
    df["TV_Radio_Interaction"] = df["TV"] * df["Radio"]
    return df


# ---------------------------------------------------------------------------
# 4. MODEL TRAINING & EVALUATION
# ---------------------------------------------------------------------------
def train_and_evaluate(df):
    feature_cols = ["TV", "Radio", "Newspaper", "Total_Spend",
                     "TV_Share", "TV_Radio_Interaction"]
    X = df[feature_cols]
    y = df["Sales"]

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42
    )

    models = {
        "Linear Regression": LinearRegression(),
        "Random Forest": RandomForestRegressor(n_estimators=200, random_state=42),
    }

    results = {}
    for name, model in models.items():
        model.fit(X_train, y_train)
        preds = model.predict(X_test)

        mae = mean_absolute_error(y_test, preds)
        rmse = np.sqrt(mean_squared_error(y_test, preds))
        r2 = r2_score(y_test, preds)
        cv_r2 = cross_val_score(model, X, y, cv=5, scoring="r2").mean()

        results[name] = {
            "model": model,
            "MAE": mae,
            "RMSE": rmse,
            "R2": r2,
            "CV_R2": cv_r2,
            "preds": preds,
        }

        print(f"\n{name}")
        print(f"  MAE : {mae:.3f}")
        print(f"  RMSE: {rmse:.3f}")
        print(f"  R2  : {r2:.3f}")
        print(f"  Cross-val R2 (5-fold): {cv_r2:.3f}")

    # Pick best model by test R2
    best_name = max(results, key=lambda k: results[k]["R2"])
    best_model = results[best_name]["model"]
    print(f"\nBest model: {best_name}")

    # Actual vs Predicted plot for the best model
    plt.figure()
    plt.scatter(y_test, results[best_name]["preds"], alpha=0.6)
    lims = [min(y_test.min(), results[best_name]["preds"].min()),
            max(y_test.max(), results[best_name]["preds"].max())]
    plt.plot(lims, lims, "r--")
    plt.xlabel("Actual Sales")
    plt.ylabel("Predicted Sales")
    plt.title(f"Actual vs Predicted Sales ({best_name})")
    plt.tight_layout()
    plt.savefig(f"{OUTPUT_DIR}/actual_vs_predicted.png", dpi=150)
    plt.close()

    # Feature importance / coefficients
    plt.figure()
    if hasattr(best_model, "feature_importances_"):
        importances = pd.Series(best_model.feature_importances_, index=feature_cols)
        importances.sort_values().plot(kind="barh", color="teal")
        plt.title("Feature Importance")
    else:
        coefs = pd.Series(best_model.coef_, index=feature_cols)
        coefs.sort_values().plot(kind="barh", color="teal")
        plt.title("Linear Regression Coefficients")
    plt.tight_layout()
    plt.savefig(f"{OUTPUT_DIR}/feature_importance.png", dpi=150)
    plt.close()

    return results, best_name, X_test, y_test


# ---------------------------------------------------------------------------
# 5. BUSINESS INSIGHTS
# ---------------------------------------------------------------------------
def print_insights(corr):
    print("\n" + "=" * 60)
    print("BUSINESS INSIGHTS")
    print("=" * 60)
    tv_corr = corr.loc["TV", "Sales"]
    radio_corr = corr.loc["Radio", "Sales"]
    news_corr = corr.loc["Newspaper", "Sales"]

    print(f"- TV spend has the strongest correlation with Sales ({tv_corr:.2f}).")
    print(f"- Radio spend shows a moderate positive correlation ({radio_corr:.2f}).")
    print(f"- Newspaper spend shows the weakest correlation ({news_corr:.2f}), "
          f"suggesting it contributes the least to driving sales.")
    print("- Recommendation: Prioritize TV and Radio budget allocation over "
          "Newspaper for stronger sales impact.")
    print("- A combined TV+Radio strategy (interaction effect) tends to lift "
          "sales more than either channel alone, indicating cross-channel synergy.")


# ---------------------------------------------------------------------------
# MAIN
# ---------------------------------------------------------------------------
if __name__ == "__main__":
    import os
    os.makedirs(OUTPUT_DIR, exist_ok=True)

    df = load_data()
    corr = explore_data(df)
    df_fe = engineer_features(df)
    results, best_name, X_test, y_test = train_and_evaluate(df_fe)
    print_insights(corr)

    print("\nDone. Charts saved in the 'outputs' folder.")
